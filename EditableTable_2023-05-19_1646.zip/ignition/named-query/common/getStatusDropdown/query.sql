SELECT
	'Pending' AS 'value',
	'Pending' AS 'label'
FROM DUAL 
UNION
SELECT
	'Active' AS 'value',
	'Active' AS 'label'
FROM DUAL
UNION
SELECT
	'Inactive' AS 'value',
	'Inactive' AS 'label'
FROM DUAL
