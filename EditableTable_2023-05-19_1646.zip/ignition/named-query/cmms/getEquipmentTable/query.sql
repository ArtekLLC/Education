SELECT
	e.*

FROM org_equipment e
WHERE
	e.equipment_status != 'Deleted'