SELECT 
	DISTINCT(equipment_type) AS 'value',
	equipment_type AS 'label'
FROM org_equipment
ORDER BY
	equipment_type ASC