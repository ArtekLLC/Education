SELECT
	area_id AS 'value',
	area_name AS 'label'
FROM org_area

ORDER BY 
	area_name ASC