CREATE TABLE `cmms_task` (
  `task_id` int NOT NULL AUTO_INCREMENT,
  `fk_equipment_id` int NOT NULL,
  `task_name` varchar(90) NOT NULL,
  `task_description` varchar(255) NOT NULL,
  `task_status` enum('Pending','Active','Inactive','Deleted') NOT NULL DEFAULT 'Pending',
  `est_hours` int NOT NULL DEFAULT '0',
  `est_minutes` int NOT NULL DEFAULT '0',
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  `fk_update_user_id` int DEFAULT NULL,
  `update_tstamp` datetime DEFAULT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `cmms_task_assignment` (
  `fk_assigned_user_id` int NOT NULL,
  `fk_task_id` int NOT NULL,
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  PRIMARY KEY (`fk_assigned_user_id`,`fk_task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `cmms_task_schedule` (
  `task_schedule_id` int NOT NULL AUTO_INCREMENT,
  `fk_task_id` int NOT NULL,
  `task_schedule_date` date NOT NULL,
  `task_schedule_status` enum('Pending','Active','Overdue','Complete') NOT NULL DEFAULT 'Pending',
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  `fk_update_user_id` int DEFAULT NULL,
  `update_tstamp` datetime DEFAULT NULL,
  PRIMARY KEY (`task_schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `cmms_workorder` (
  `workorder_id` int NOT NULL AUTO_INCREMENT,
  `fk_equipment_id` int NOT NULL,
  `workorder_description` varchar(255) NOT NULL,
  `workorder_status` enum('Pending','Active','Rejected','Complete') NOT NULL DEFAULT 'Pending',
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  `fk_update_user_id` int DEFAULT NULL,
  `update_tstamp` datetime DEFAULT NULL,
  PRIMARY KEY (`workorder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `cmms_workorder_assignment` (
  `fk_assigned_user_id` int NOT NULL,
  `fk_workorder_id` int NOT NULL,
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  PRIMARY KEY (`fk_assigned_user_id`,`fk_workorder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `org_area` (
  `area_id` int NOT NULL AUTO_INCREMENT,
  `area_name` varchar(90) NOT NULL,
  `area_description` varchar(255) NOT NULL,
  `area_status` enum('Pending','Active','Inactive','Deleted') NOT NULL DEFAULT 'Pending',
  `fk_site_id` int NOT NULL,
  `fk_parent_area_id` int DEFAULT NULL,
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  `fk_update_user_id` int DEFAULT NULL,
  `update_tstamp` datetime DEFAULT NULL,
  PRIMARY KEY (`area_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `org_enterprise` (
  `enterprise_id` int NOT NULL AUTO_INCREMENT,
  `enterprise_name` varchar(45) NOT NULL,
  `enterprise_description` varchar(255) NOT NULL,
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  `fk_update_user_id` int DEFAULT NULL,
  `update_tstamp` datetime DEFAULT NULL,
  PRIMARY KEY (`enterprise_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `org_equipment` (
  `equipment_id` int NOT NULL AUTO_INCREMENT,
  `equipment_name` varchar(90) NOT NULL,
  `equipment_description` varchar(255) NOT NULL,
  `equipment_type` varchar(45) NOT NULL,
  `equipment_status` enum('Pending','Active','Inactive','Deleted') NOT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `manufactuer` varchar(90) DEFAULT NULL,
  `model` varchar(90) DEFAULT NULL,
  `serialnumber` varchar(90) DEFAULT NULL,
  `fk_area_id` int NOT NULL,
  `fk_workcell_id` int DEFAULT NULL,
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  `fk_update_user_id` int DEFAULT NULL,
  `update_tstamp` datetime DEFAULT NULL,
  PRIMARY KEY (`equipment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `org_site` (
  `site_id` int NOT NULL AUTO_INCREMENT,
  `site_name` varchar(45) NOT NULL,
  `site_description` varchar(255) NOT NULL,
  `site_status` enum('Pending','Active','Inactive','Deleted') NOT NULL DEFAULT 'Pending',
  `country_code` varchar(3) NOT NULL,
  `state_code` varchar(2) NOT NULL,
  `city` varchar(90) NOT NULL,
  `street` varchar(90) NOT NULL,
  `building_number` int NOT NULL,
  `suite_number` varchar(10) DEFAULT NULL,
  `zipcode` int NOT NULL,
  `fk_enterprise_id` int NOT NULL,
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  `fk_update_user_id` int DEFAULT NULL,
  `update_tstamp` datetime DEFAULT NULL,
  PRIMARY KEY (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `org_workcell` (
  `workcell_id` int NOT NULL AUTO_INCREMENT,
  `workcell_name` varchar(90) NOT NULL,
  `workcell_description` varchar(255) NOT NULL,
  `workcell_status` enum('Pending','Active','Inactive','Deleted') NOT NULL DEFAULT 'Pending',
  `fk_area_id` int NOT NULL,
  `fk_insert_user_id` int NOT NULL,
  `insert_tstamp` datetime NOT NULL,
  `fk_update_user_id` int DEFAULT NULL,
  `update_tstamp` datetime DEFAULT NULL,
  PRIMARY KEY (`workcell_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
