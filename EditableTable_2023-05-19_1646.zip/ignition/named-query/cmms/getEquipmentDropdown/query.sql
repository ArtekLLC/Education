SELECT
	equipment_name AS 'label',
	equipment_id AS 'value'
	
FROM org_equipment

WHERE
	CASE WHEN :workcell_id IS NULL THEN 
		:area_id = fk_area_id OR :area_id = -1
			ELSE :workcell_id = fk_workcell_id OR :workcell_id = -1
				END

ORDER BY 
	equipment_name ASC