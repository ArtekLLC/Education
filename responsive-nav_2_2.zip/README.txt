         .8.          8 888888888o. 8888888 8888888888 8 8888888888   8 8888     ,88'                                                                             
        .888.         8 8888    `88.      8 8888       8 8888         8 8888    ,88'                                                                              
       :88888.        8 8888     `88      8 8888       8 8888         8 8888   ,88'                                                                               
      . `88888.       8 8888     ,88      8 8888       8 8888         8 8888  ,88'                                                                                
     .8. `88888.      8 8888.   ,88'      8 8888       8 888888888888 8 8888 ,88'                                                                                 
    .8`8. `88888.     8 888888888P'       8 8888       8 8888         8 8888 88'                                                                                  
   .8' `8. `88888.    8 8888`8b           8 8888       8 8888         8 888888<                                                                                   
  .8'   `8. `88888.   8 8888 `8b.         8 8888       8 8888         8 8888 `Y8.                                                                                 
 .888888888. `88888.  8 8888   `8b.       8 8888       8 8888         8 8888   `Y8.                                                                               
.8'       `8. `88888. 8 8888     `88.     8 8888       8 888888888888 8 8888     `Y8.                                                                             


## Responsive Navigation Menu - Version 2.2


## Requirements
1. Ignition Version 8.1.22
2. Ignition Perspective Module


## Installation: 
1. Import a new project. 
	- You can import this resource as its own project from the Gateway or from the Ignition Designer Launcher. 
	- From the Gateway, Select the Config tab on the left. Then go to Projects. There, you will find the link to import the project. 
	- From the Ignition Designer Launcher, launch the designer for your gateway. When the project selection window appears, click the Import Project button in the top right. 
2. Import into an existing project. 
	- This resource follows the Ignition Exchange best practices, making it easy to import into any existing project. Inside the Ignition Designer, open the File menu and select Import. Locate the .zip file in the same folder as this Readme file. You will be presented with a popup window showing all of the project resources in the .zip file, and you can deselect resources you want to exclude from the import. 
	- If you are importing into an existing project, consider deselecting Page Configuration and Advanced Stylesheets. If left selected, any page urls and docks, and any styles already defined in the Advanced Stylesheet will be overwritten. 
3. If you do deselect the Page Configuration, here are the default settings for the top and left docks so that you can manually configure them in the Page Configuration's Shared Settings:

Top Dock
View: Exchange/Responsive Nav/Top Bar
Resize: false
Display: visible
Content: push
Anchor: fixed
Size: 50
Dock ID: top
Handle: hide

Left Dock
View: Exchange/Responsive Nav/Nav
Resize: false
Display: visible
Content: auto
Anchor: fixed
Size: 50
Dock ID: nav
Handle: hide

4. If you deselect the Advanced Stylesheet, you can copy and paste the code into your project's advanced stylesheet from the styles.css file located in the same folder as this Readme file. 


## Use and Customization
1. This resource uses css color variables. You can change the values for these variables in the top :root section of the advanced stylesheet.
2. The main nav view (Exchange/Responsive Nav/Nav) comes preconfigured with examples of a company logo and several nav links and nav sections. You can simply duplicate any of these examples to create another instance of the nav element, or drag a nav element onto the canvas from the project navigation panel. To replace the company logo, have the Top Logo container deep selected and drag and drop or copy and paste your .png image. You can have two versions of a logo: one for the collapsed nav menu and one for the expanded nav menu. Be sure to apply the same style classes to your logos that can be found on the examples. 
3. In order to style the active nav element, you will have to set up your page URL's in a particular way. Take for example the page URL, "/nav-section-tree/folder-1/child-1/grandchild-1". This is the inner-most leaf node in the Nav Section Tree example element. If we're on that page, when the nav menu is collapsed, the root nav element, "Nav Section Tree" will be highlighted, and when the nav section is expanded the element for Grandchild 1 will be highlighted. So for nav section links, use page URL's that begin with the section name, and use a forward slash (/) to separate the section from the page. For nav links in general, use page URL's that end with the label for the link. Use hyphens (-) in the page URL's where you have spaces in your nav link labels. 


## Contact:
https://www.artekis.io/contact


## Authors and Acknowledgment
Built for the [Ignition Exchange](https://inductiveautomation.com/exchange) by Artek Integrated Solutions